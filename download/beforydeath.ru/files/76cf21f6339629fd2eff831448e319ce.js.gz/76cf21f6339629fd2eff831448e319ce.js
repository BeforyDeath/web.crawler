/**
 * Created by JetBrains PhpStorm.
 * User: BeforyDeath
 * Date: 25.07.13 - 12:25
 */

$(document).ready(function() {
	$('#logo').hover(function(){
		$('img').hide();
		$(this).stop().animate({
			marginLeft:"-140px",
			width:"260px"
		},function(){
			$('#logo span').show().stop().animate({
				opacity:'1'
			},300);
		});
		$('#chY').stop().animate({
			left:"40px",
			top:"-27px"
		});
		$('#chD').stop().animate({
			left:"80px"
		});

	},function(){
		$('#logo span').show().animate({
			opacity:'0'
		},200);
		$(this).stop().animate({
			marginLeft:"-100px",
			width:"180px"
		},function(){
			$('img').show();
		});
		$('#chY').stop().animate({
			left:"0px",
			top:"0px"
		});
		$('#chD').stop().animate({
			left:"0px"
		});
	});
});